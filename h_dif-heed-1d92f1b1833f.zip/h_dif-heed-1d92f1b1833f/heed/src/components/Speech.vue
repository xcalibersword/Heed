<template>
  <span>
    <b-badge @click="startRecognition()" class="microphone" pill style="background-color:#5eb1bf;">
      <p style="display:inline;" v-if="!started">{{message}}</p>
      <img style="height:1.5em;" src="../assets/microphone-solid.svg">
    </b-badge>
    <p v-for="word in transcription">{{ word }}</p>
    <p>{{ runtimeTranscription }}</p>
  </span>
</template>

<script>
import { EventBus } from "../event-bus";

export default {
  name: "vue-speech",
  props: {
    lang: {
      type: String,
      default: "en-US"
    }
  },
  data: () => ({
    message: "",
    passback: [],
    runtimeTranscription: "",
    transcription: [],
    started: false
  }),
  methods: {
    checkApi() {
      window.SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition && process.env.NODE_ENV !== "production") {
        throw new Error(
          "Speech Recognition does not exist on this browser. Use Chrome or Firefox"
        );
      }
      if (!SpeechRecognition) {
        return;
      }
      const recognition = new SpeechRecognition();
      recognition.lang = this.lang;
      recognition.interimResults = true;
      recognition.addEventListener("result", event => {
        const text = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join("");
        this.runtimeTranscription = text;
      });
      recognition.addEventListener("end", () => {
        if (this.runtimeTranscription !== "") {
          this.transcription.push(this.runtimeTranscription);
          this.$emit("onTranscriptionEnd", {
            transcription: this.transcription,
            lastSentence: this.runtimeTranscription
          });
        }

        this.runtimeTranscription = "";
        recognition.start();
      });
      recognition.start();
    },

    startRecognition() {
      this.checkApi();
      this.started = true;
    }
  },
  mounted() {
    console.log("mounted");
  }
};
</script>
<style>
.microphone {
  text-align: center;
  margin: auto;
  font-size: 1.5em;
  margin-top: 1em;
  padding: 0.5em;
  width: 90%;
}
</style>