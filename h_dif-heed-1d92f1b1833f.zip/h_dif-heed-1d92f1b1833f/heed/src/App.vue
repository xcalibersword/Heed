<template>
  <div id="app">
    <HelloWorld></HelloWorld>
    <Speech/>
    <!-- <test></test> -->
  </div>
</template>

<script>
import Vue from "vue";
import BootstrapVue from "bootstrap-vue";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-vue/dist/bootstrap-vue.css";
import VueSpeech from "vue-speech";
// import socketio from "socket.io";
// import VueSocketIO from "vue-socket.io";

// export const SocketInstance = socketio("http://localhost:4113");

// Vue.use(VueSocketIO, SocketInstance);

Vue.use(VueSpeech);

Vue.use(BootstrapVue);

import HelloWorld from "./components/HelloWorld.vue";
import test from "./components/Test.vue";
import Speech from "./components/Speech.vue";

export default {
  name: "app",
  components: {
    HelloWorld,
    test,
    Speech
  }
};
</script>

<style>
#app {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* margin-top: 60px; */
  height: 100%;
  color: white;

  background: -moz-linear-gradient(
    93deg,
    rgba(239, 123, 69, 1) 0%,
    rgba(94, 177, 191, 1) 100%
  ); /* ff3.6+ */
  background: -webkit-gradient(
    linear,
    left top,
    left bottom,
    color-stop(0%, rgba(94, 177, 191, 1)),
    color-stop(100%, rgba(239, 123, 69, 1))
  ); /* safari4+,chrome */
  background: -webkit-linear-gradient(
    93deg,
    rgba(239, 123, 69, 1) 0%,
    rgba(94, 177, 191, 1) 100%
  ); /* safari5.1+,chrome10+ */
  background: -o-linear-gradient(
    93deg,
    rgba(239, 123, 69, 1) 0%,
    rgba(94, 177, 191, 1) 100%
  ); /* opera 11.10+ */
  background: -ms-linear-gradient(
    93deg,
    rgba(239, 123, 69, 1) 0%,
    rgba(94, 177, 191, 1) 100%
  ); /* ie10+ */
  background: linear-gradient(
    357deg,
    rgba(239, 123, 69, 1) 0%,
    rgba(94, 177, 191, 1) 100%
  ); /* w3c */
  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5EB1BF', endColorstr='#EF7B45',GradientType=0 ); /* ie6-9 */
}
</style>
