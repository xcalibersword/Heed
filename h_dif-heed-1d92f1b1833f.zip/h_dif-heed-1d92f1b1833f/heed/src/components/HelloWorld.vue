<template style="height:100%;">
  <b-container>
    <h1>Heed</h1>
    <!-- <h1>Mood: {{mood}}</h1> -->

    <img v-if="loading" src="../assets/spinner.gif" style="width:5em;">
    <hgroup v-if="!loading" class="speech-bubble">
      <h3>Hi, how are you?</h3>
    </hgroup>
    <b-row>
      <b-col class="mb-4" v-for="e in emotions" :key="e.label" cols="4">
        <img
          v-on:click="mood += e.moodIndex"
          :src="getImgUrl(e.label)"
          style="border-radius: 50px;"
        >
      </b-col>
    </b-row>
  </b-container>
</template>

<script>
import { EventBus } from "../event-bus";

export default {
  name: "HelloWorld",
  data: function() {
    return {
      loading: true,
      mood: 0,
      emotions: [
        { moodIndex: 3, label: "happy" },
        { moodIndex: -5, label: "angry" },
        { moodIndex: -4, label: "frustrated" },
        { moodIndex: -1, label: "meh" },
        { moodIndex: -3, label: "sad" },
        { moodIndex: -2, label: "shock" },
        { moodIndex: -3, label: "tired" },
        { moodIndex: 4, label: "funny" },
        { moodIndex: -1, label: "bored" }
      ]
    };
  },
  methods: {
    getImgUrl(e) {
      return require("../assets/" + e + ".svg");
    },
    loadingFinished() {
      this.loading = false;
    }
  },
  mounted: function() {
    // EventBus.$on("think-of-answer")
    setTimeout(this.loadingFinished, 1000);
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}

.speech-bubble {
  margin: auto;
  text-align: center;
  width: 80%;
  position: relative;
  background: #b5a7bb;
  border-radius: 1em;
}

.speech-bubble:after {
  content: "";
  position: absolute;
  left: 2px;
  top: 50%;
  width: 0;
  height: 0;
  border: 15px solid transparent;
  border-right-color: #b5a7bb;
  border-left: 0;
  border-top: 0;
  margin-top: -7.5px;
  margin-left: -15px;
}
</style>
